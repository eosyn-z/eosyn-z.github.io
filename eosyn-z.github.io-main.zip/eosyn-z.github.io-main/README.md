# Personal Portfolio & Knowledge Base Template

A fast, customizable personal website template with knowledge management, recommended sites, and bookmarks. No frameworks - just vanilla HTML/CSS/JS with a Node.js build system.

**Perfect for:** Developers, researchers, students, digital gardeners, anyone who wants a personal site!

## Features

-  **Markdown-based content** - Write in `content/` folders, auto-builds to beautiful pages
-  **Recommended sites** - Curate external links with custom tags and filtering
-  **Bookmark manager** - Visitors can save favorites (localStorage-based)
- 🔍 **Full-text search** - Search your content with relevance scoring
-  **Citations system** - arXiv, PubMed, nLab, DOI support
- 🕸️ **Wiki-style backlinks** - `[[Article Name]]` creates automatic connections
-  **5 themes** - Dracula, Light, Nord, Monokai, Alice (switchable)
-  **Galleries** - Nature backgrounds, art carousel, games
- 🪟 **Desktop mode** - OS-style window management interface
- 🤖 **GitHub Actions** - Auto-builds and deploys on push
-  **Discord integration** - Optional presence display

## Quick Start

**New here?** → [QUICKSTART.md](QUICKSTART.md) - Get running in 5 minutes

**Developers:**
```bash
npm install          # Install dependencies
npm run build        # Build manifest, gallery, and sites
npx serve .          # Serve locally at http://localhost:3000
```

## Easy Customization (No Coding!)

Everything is configured in text files:

### `config/settings.txt`
```
SITE_TITLE=Your Name
MOTD=Your tagline here
DEFAULT_THEME=monokai
DISCORD_USER_ID=your-discord-id
```

### `config/sites.txt`
```
SITE=GitHub|https://github.com|Code hosting|Tool,Learning
SITE=Your Site|https://example.com|Description|Personal,Portfolio
```

Add markdown files to `content/` folders, run `npm run build`, done!

**Full documentation:** [docs/README.md](docs/README.md)

## Deployment

### GitHub Pages (Recommended - Auto-Deploy)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/yourusername/yourrepo.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   - Repository Settings → Pages
   - Source: **GitHub Actions**
   - Wait 1-2 minutes

3. **Live at:** `https://yourusername.github.io/yourrepo/`

The included workflow auto-builds on every push!

### Netlify/Vercel

- Build command: `npm run build`
- Publish directory: `.` (root)

## Project Structure

```
├── config/          # Configuration files
│   ├── settings.txt     # Site settings
│   ├── sites.txt        # Recommended sites
│   └── motd.txt         # Message of the day
├── content/         # Your markdown content
│   ├── projects/
│   ├── thoughts/
│   ├── learning/
│   └── resources/
├── docs/            # Documentation
├── gallery/         # Images (art/nature)
├── games/           # Game scripts
├── pages/           # Additional HTML pages
├── assets/          # Scripts, styles, images
│   ├── js/
│   │   ├── core/        # Main scripts
│   │   ├── utils/       # Utility scripts
│   │   └── build/       # Build tools
│   └── css/
├── data/            # Generated JSON data
└── [generated files are gitignored]
```

## Available Tags for Sites

Tool, Social, Business, Under Construction, Personal, Fun, Game, Portfolio, Learning

## Documentation

- [QUICKSTART.md](QUICKSTART.md) - 5-minute setup guide
- [docs/README.md](docs/README.md) - Complete documentation
- [docs/TEMPLATES.md](docs/TEMPLATES.md) - Content templates and schemas

## Troubleshooting

**Build fails?**
```bash
rm -rf node_modules && npm install && npm run build
```

**Changes not showing?** Run `npm run build` after editing config or content

**Site not deploying?** Check GitHub Actions tab for build logs

## Architecture

**Build time:** `content/*.md` → `build.js` → `manifest.json`, `sites.json`, `gallery/images.json`

**Runtime:** Browser loads JSON, displays pre-computed data (fast!)

## License

MIT - Use for personal or commercial projects freely

---

**No frameworks • Pure performance • Open source**
