# Nature Photography

Natural beauty and landscapes captured through my lens.

---
type: gallery
display: grid
items_source: gallery/nature
---

A collection of nature photography featuring landscapes, wildlife, and the natural world's beautiful moments.