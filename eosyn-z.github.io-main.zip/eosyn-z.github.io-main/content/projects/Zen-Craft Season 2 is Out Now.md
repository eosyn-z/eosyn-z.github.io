## Join : zen-craft.apexmc.co / 98.142.5.204:25565

# What's the server about?

This server is meant to be a "nearly vanilla" but not quite server that contains a simple claims plugin and a few others for aesthetic additions that don't really change gameplay. This includes essentials like Warps, which are only set for major server builds (such as the Casino which contains custom models, the Hub, and the Spawn for Season2). This includes the ability to claim blocks with a shovel, etc. I'm working on a custom modpack for a later modded server. For now, users are just able to sell items to the server for currency in order to exchange them for these un-craftable models added with ItemsAdder. I'm working on converting some items from Yuushya into items that we can place in this vanilla game while only requiring a custom texture pack (which is installed for you dynamically). In the meantime, we're going to have some broken textures while I work this stuff out. Sorry! Once it's done it'll be perfect though!

Custom items are allowed in both survival as well as creative, but the economy system is only connected to survival.
All things are a work in progress! 
## Survival Multi-Player (SMP)

This is exactly what you'd expect with Survival: Just regular minecraft with only the addition of /warp and the ability to claim regions. Though I do ban players who intentionally grief! Craft a golden shovel to designate the areas of your claims. You can do /sethome, which if you haven't seen that command before, it allows you to teleport back to your place with /home. Let me know if you lost anything in the process, or if you want a copy of the old server builds. I've saved the entire Season 1 map. [[What happened with Season 1 of Zen-Craft]]?

## Creative worlds (custom)

I'm working on using the skript plugin to create custom multiverses with permissions for each individual user, starting with a void world and a specific WorldEdit schematic, so that you have an entire world for yourself in which you can set the weather etc. Work in progress! Once complete, you'll be able to use the WorldEdit region selection to submit builds to build competitions. 

## Zen-Craft Modpack (WIP)

I'm still taking suggestions for what might be the most entertaining things to include in a modpack. I've already worked on porting WebDisplays partially over to Fabric 1.20.1, so we'll be able to have some interesting things on here. Personally, I'm partial to Eureka with Valkyrien Skies as well as the Aether, plus the grappling hook mod and some other aesthetic content like Yuushya. What do you all think? Leave suggestions in the Discord for me, I'd appreciate that.

This is not fully functional yet! I'll make another announcement when it is. Thank you for reading!