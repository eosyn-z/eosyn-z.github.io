
I've been working on this little personal site for a month or two ish, passively, since I both wasn't sure what to put on here and wasn't sure how I wanted to structure it. But, 11/1 is the day!~ I hope that you actually like it.

I've enabled linking so that I can just copy and paste the things that I write in my Obsidian in here, so I'll be uploading I guess articles or random ramblings here instead. If you like what you see, I've made a "Shop" page that includes RedBubble to actually buy art from me, and other random things. I don't have all of this filled out yet, and you'll probably see random little changes through the coming days since most of this was vibe coded. It turns out that Claude is quite effective with visual direction! However, I refuse to allow there to be any generated text on this website. Every word you see was actually written by me. It's unfortunate that I have to say that, isn't it?

By the way - We have a Minecraft server, [[Zen-Craft Season 2 is Out Now]] Check the article to see more details of it.
